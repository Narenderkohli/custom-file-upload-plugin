<?php
/**
* Plugin Name: Multiple Files Upload
* Description: You can add multiple images and crop them.
* Version: 6.7.2
* Author: WordPress Test
**/


if (!defined('ABSPATH')) {
    exit;
}


require_once plugin_dir_path(__FILE__) . 'includes/file-upload-functions.php';





// Hook to add menu
add_action('admin_menu', 'mfu_add_admin_menu');

function mfu_add_admin_menu() {
    add_menu_page(
        'Multiple Files Upload', 
        'Custom Multiple Files Upload', 
        'manage_options',
        'mfu-settings', 
        'mfu_settings_page', 
        'dashicons-upload',
        66
    );
}

// Callback function for the menu page
function mfu_settings_page() {
    ?>
    <div class="wrap">
        <h1>Multiple Files Upload Settings</h1>
        <p>Welcome to the Multiple Files Upload plugin settings page.</p>
    </div>
    <?php
}
?>

